﻿using PacmanGUI.GL;
using PacmanGUI.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PacmanGUI
{
    public partial class Form1 : Form
    {
        PacmanPlayer pacman;
        List<Ghost> ghosts = new List<Ghost>();
        GameDirection pacmanDirection = GameDirection.Right;
        private int GameScore
        {
            get => int.Parse(label1.Text);
            set
            {
                label1.Text = value.ToString();
            }
        }
        public Form1()
        {
            InitializeComponent();
            GameGrid grid = new GameGrid("maze.txt", 24, 70);
            GameCell cell = grid.GetCell(2, 3);
            pacman = new PacmanPlayer(cell);
            ghosts.Add(new HorizontalGhost(grid.GetCell(2,1)));
            ghosts.Add(new VerticalGhost(grid.GetCell(22, 1)));
            ghosts.Add(new RandomGhost(grid.GetCell(50, 8)));
            ghosts.Add(new SmartGhost(pacman,grid.GetCell(40, 8)));
            PrintMaze(grid);
            Thread thread = new Thread(KeyboardMovements);
            thread.Start();
        }
        private void KeyboardMovements()
        {
            while (!IsDisposed)
            {
                if (KeyBoard.IsKeyPressed(Key.UpArrow))
                {
                    pacmanDirection = GameDirection.Up;
                }
                else if (KeyBoard.IsKeyPressed(Key.DownArrow))
                {
                    pacmanDirection = GameDirection.Down;
                }
                else if (KeyBoard.IsKeyPressed(Key.LeftArrow))
                {
                    pacmanDirection = GameDirection.Left;
                }
                else if (KeyBoard.IsKeyPressed(Key.RightArrow))
                {
                    pacmanDirection = GameDirection.Right;
                }
            }
        }
        private void PrintMaze(GameGrid grid)
        {
            for (int y = 0; y < grid.Rows; y++)
            {
                for (int x = 0; x < grid.Cols; x++)
                {
                    GameCell cell = grid.GetCell(x, y);
                    Controls.Add(cell.PictureBox);
                }
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void RunningTimer_Tick(object sender, EventArgs e)
        {
            pacman.Move(pacmanDirection);
            foreach(Ghost ghost in ghosts)
            {
                ghost.Move();
            }
            GameScore = pacman.Score;
        }
    }
}
