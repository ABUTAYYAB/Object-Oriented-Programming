﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    class SmartGhost : Ghost
    {
        PacmanPlayer player;
        public SmartGhost(PacmanPlayer player, GameCell gameCell) : base('S', gameCell)
        {
            this.player = player;
        }
        public override GameCell Move()
        {
            GameCell nextCell = CalculateNextCell();
            GameCell currentCell = CurrentCell;
            GameObject gameObject = new GameObject(nextCell.CurrentGameObject);
            CurrentCell = nextCell;
            if (currentCell != nextCell)
            {
                currentCell.CurrentGameObject = previousObject;
                previousObject = gameObject;
            }
            return nextCell;
        }
        private GameCell CalculateNextCell()
        {
            GameCell next;
            double distance;
            double horizontalDifference;
            double verticalDifference;
            double shortestDistance = 100000000;
            int shortestDirection = 0;
            for (int i = 0; i < 4; i++)
            {
                next = CurrentCell.NextCell((GameDirection)i);
                horizontalDifference = Math.Abs(next.X - player.CurrentCell.X);
                verticalDifference = Math.Abs(next.Y - player.CurrentCell.Y);
                distance = Math.Pow(horizontalDifference, 2) + Math.Pow(verticalDifference, 2);
                if (distance <= shortestDistance)
                {
                    shortestDistance = distance;
                    shortestDirection = i;
                }
            }
            return CurrentCell.NextCell((GameDirection)shortestDirection);
        }
    }
}
