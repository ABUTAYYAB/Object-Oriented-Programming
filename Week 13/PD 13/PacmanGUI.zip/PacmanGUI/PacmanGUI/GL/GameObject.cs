﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PacmanGUI.Properties;
namespace PacmanGUI.GL
{
    class GameObject
    {
        protected Image _displayImage;
        private char displayCharacter;
        protected GameCell _currentCell;
        protected GameObjectType _gameObjectType;
        public GameObject(GameObject gameObject):this(gameObject.GameObjectType,gameObject.DisplayImage)
        {
        }
        public GameObject(GameObjectType type, Image image)
        {
            GameObjectType = type;
            DisplayImage = image;
        }
        public GameObject(GameObjectType type, char displayCharacter)
        {
            GameObjectType = type;
            DisplayCharacter = displayCharacter;
            switch (displayCharacter)
            {
                case 'P':
                    DisplayImage = Resources.pacman_open;
                    break;
                case '|':
                case '%':
                    DisplayImage = Resources.vertical;
                    break;
                case '#':
                    DisplayImage = Resources.horizontal;
                    break;
                case '.':
                    DisplayImage = Resources.pallet;
                    break;
                case 'H':
                    DisplayImage = Resources.ghost_blue;
                    break;
                case 'V':
                    DisplayImage = Resources.ghost_pink;
                    break;
                case 'R':
                    DisplayImage = Resources.ghost_fright;
                    break;
                case 'S':
                    DisplayImage = Resources.ghost_red;
                    break;
            }
        }

        public Image DisplayImage { get => _displayImage; set => _displayImage = value; }
        public GameCell CurrentCell
        {
            get => _currentCell;
            set
            {
                _currentCell = value;
                _currentCell.CurrentGameObject = this;
            }
        }
        public GameObjectType GameObjectType { get => _gameObjectType; set => _gameObjectType = value; }
        public char DisplayCharacter { get => displayCharacter; set => displayCharacter = value; }

        public static GameObjectType GetGameObjectType(char displayCharacter)
        {
            switch (displayCharacter)
            {
                case 'P': return GameObjectType.PLAYER;
                case '#':
                case '%':
                case '|': return GameObjectType.WALL;
                case '.': return GameObjectType.REWARD;
                default: return GameObjectType.NONE;
            }
        }
    }
}
