﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    abstract class Ghost : GameObject
    {
        protected GameObject previousObject;
        public Ghost(char displayCharacter, GameCell gameCell) : base(GameObjectType.ENEMY, displayCharacter)
        {
            previousObject = gameCell.CurrentGameObject;
            CurrentCell = gameCell;
        }

        public abstract GameCell Move();
    }
}
