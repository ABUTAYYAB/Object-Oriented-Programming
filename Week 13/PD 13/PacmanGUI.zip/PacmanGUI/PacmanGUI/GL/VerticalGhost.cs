﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    class VerticalGhost : Ghost
    {
        private GameDirection gameDirection;
        public VerticalGhost(GameCell gameCell) : base('V', gameCell)
        {
            gameDirection = GameDirection.Up;
        }

        public override GameCell Move()
        {
            GameCell currentCell = CurrentCell;
            GameCell nextCell = CurrentCell.NextCell(gameDirection);
            GameObject gameObject = new GameObject(nextCell.CurrentGameObject);
            CurrentCell = nextCell;
            if (currentCell != nextCell)
            {
                currentCell.CurrentGameObject = previousObject;
                previousObject = gameObject;
            }
            if (currentCell == nextCell)
            {
                ToggleDirection();
            }
            return nextCell;
        }
        private void ToggleDirection()
        {
            if (gameDirection == GameDirection.Up)
            {
                gameDirection = GameDirection.Down;
            }
            else
            {
                gameDirection = GameDirection.Up;
            }
        }
    }
}
