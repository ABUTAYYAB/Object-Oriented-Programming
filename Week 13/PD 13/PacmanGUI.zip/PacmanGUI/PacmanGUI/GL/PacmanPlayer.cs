﻿using PacmanGUI.Properties;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    class PacmanPlayer : GameObject
    {
        private int pacmanStateCounter;
        private bool pacmanState;
        private Image image;
        public PacmanPlayer(GameCell gameCell) : base(GameObjectType.PLAYER, Resources.pacman_open)
        {
            CurrentCell = gameCell;
            pacmanStateCounter = 0;
            pacmanState = false;
            this.image = Resources.pacman_open;
        }

        public int Score { get; set; }

        public GameCell Move(GameDirection gameDirection)
        {
            GameCell currentCell = CurrentCell;
            GameCell nextCell = CurrentCell.NextCell(gameDirection);
            GameObjectType objectType = nextCell.CurrentGameObject.GameObjectType;
            CurrentCell = nextCell;
            if (currentCell != nextCell)
            {
                currentCell.CurrentGameObject = new GameObject(GameObjectType.NONE, ' ');
                if (objectType == GameObjectType.REWARD)
                {
                    Score += 5;
                }
            }
            pacmanStateCounter++;
            if (pacmanStateCounter == 2)
            {
                pacmanStateCounter = 0;
                if (pacmanState == false)
                {
                    pacmanState = true;
                    image = Resources.pacman_close;
                }
                else
                {
                    pacmanState = false;
                    image = Resources.pacman_open;
                }
            }
            SetPlayerOrientation(gameDirection);
            return nextCell;
        }
        private void SetPlayerOrientation(GameDirection direction)
        {
            Image image = (Image)this.image.Clone();
            switch (direction)
            {
                case GameDirection.Up:image.RotateFlip(RotateFlipType.Rotate270FlipNone);break;
                case GameDirection.Left:image.RotateFlip(RotateFlipType.Rotate180FlipNone);break;
                case GameDirection.Right:image.RotateFlip(RotateFlipType.RotateNoneFlipNone);break;
                case GameDirection.Down:image.RotateFlip(RotateFlipType.Rotate90FlipNone);break;
            }
            CurrentCell.PictureBox.Image = image;
        }
    }
}
