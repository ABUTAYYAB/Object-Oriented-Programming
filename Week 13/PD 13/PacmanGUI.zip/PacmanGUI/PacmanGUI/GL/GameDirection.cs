﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    enum GameDirection
    {
        Up,
        Down,
        Left,
        Right
    }
}
