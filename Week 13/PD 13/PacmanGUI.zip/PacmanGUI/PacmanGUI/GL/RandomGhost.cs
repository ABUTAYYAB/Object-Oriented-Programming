﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    class RandomGhost : Ghost
    {
        public RandomGhost(GameCell gameCell) : base('R', gameCell)
        {

        }
        public override GameCell Move()
        {
            GameCell nextCell;
            do
            {
                nextCell = CurrentCell.NextCell(RandomDirection());
            }
            while (nextCell.CurrentGameObject.GameObjectType == GameObjectType.WALL);
            GameCell currentCell = CurrentCell;
            GameObject gameObject = new GameObject(nextCell.CurrentGameObject);
            CurrentCell = nextCell;
            if (currentCell != nextCell)
            {
                currentCell.CurrentGameObject = previousObject;
                previousObject = gameObject;
            }
            return nextCell;
        }
        private GameDirection RandomDirection()
        {
            switch((new Random()).Next(0, 4))
            {
                case 0:return GameDirection.Up;
                case 1:return GameDirection.Down;
                case 2:return GameDirection.Left;
                default:return GameDirection.Right;
            }

          
        }
    }
}
