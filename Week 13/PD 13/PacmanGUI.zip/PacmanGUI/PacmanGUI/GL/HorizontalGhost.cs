﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGUI.GL
{
    class HorizontalGhost : Ghost
    {
        private GameDirection gameDirection;
        public HorizontalGhost(GameCell gameCell) : base('H', gameCell)
        {
            gameDirection = GameDirection.Right;
        }

        public override GameCell Move()
        {
            GameCell currentCell = CurrentCell;
            GameCell nextCell = CurrentCell.NextCell(gameDirection);
            GameObject gameObject = new GameObject(nextCell.CurrentGameObject);
            CurrentCell = nextCell;
            if (currentCell != nextCell)
            {
                currentCell.CurrentGameObject = previousObject;
                previousObject = gameObject;
            }
            if (currentCell == nextCell)
            {
                ToggleDirection();
            }
            return nextCell;
        }
        private void ToggleDirection()
        {
            if (gameDirection == GameDirection.Left)
            {
                gameDirection = GameDirection.Right;
            }
            else
            {
                gameDirection = GameDirection.Left;
            }
        }
    }
}