﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameDLL.BL
{
    public enum ObjectType
    {
        player,enemy,bullet 
    }
}
