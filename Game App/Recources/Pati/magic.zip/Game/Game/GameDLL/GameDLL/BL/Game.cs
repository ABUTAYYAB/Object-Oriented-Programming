﻿using GameDLL.DLLinterface;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameDLL.BL
{
    public class Game
    {
        private static Game gameInstance;
        List<GameObject> gameObjectList;
        Form container;
        List<CollisionDetection> collisions;
        public static Point playerlocation;
        public int score = 0;

        public Game(Form container)
        {
            this.gameObjectList = new List<GameObject>();
            this.container = container;
            collisions = new List<CollisionDetection>();
        }
        
        public static Game getInstance(Form container)
        {
            gameInstance=new Game(container);
            return gameInstance;
        }
        public void AddGameObjects(GameObject myobject)
        {
            GameObject gameObject = myobject;
            gameObjectList.Add(gameObject);
            container.Controls.Add(gameObject.getPictureBox());
        }

        public void update()
        {
            foreach (GameObject gameObject in gameObjectList)
            {
                gameObject.update();
               
            }
            gameObjectList=checkCollionsForEnemy();
            CheckCollisions();
            removeObject();
            //removebullet();
        }

        public void CheckCollisions()
        {
            
            foreach (GameObject GO in gameObjectList)
            {
                if (GO.getObjectType() == ObjectType.player)
                {

                    foreach (GameObject GO1 in gameObjectList)
                    {
                        if (GO1.getObjectType() == ObjectType.enemy)
                        {

                            if (CollisionDetection.IsCollided(GO, GO1))
                            {
                                CollisionDetection cd = new CollisionDetection(GO, GO1);
                                collisions.Add(cd);
                                GO.health -= 5;
                            }
                        }
                        if (GO1.getObjectType() == ObjectType.bullet)
                        {
                            if (CollisionDetection.IsCollided(GO, GO1))
                            {
                                CollisionDetection cd = new CollisionDetection(GO, GO1);
                                collisions.Add(cd);
                                GO.health -= 5;
                                GO1.health -= 5;
       
                            }
                        }
                    }
                }
                if(GO.getObjectType() == ObjectType.enemy)
                {
                    foreach (GameObject GO1 in gameObjectList)
                    {
                        
                        if (GO1.getObjectType() == ObjectType.bullet)
                        {
                            if (CollisionDetection.IsCollided(GO, GO1))
                            {
                                CollisionDetection cd = new CollisionDetection(GO, GO1);
                                collisions.Add(cd);
                                GO.health -= 5;
                                GO1.health = 0;
                                score += 5;
                            }
                        }
                    }
                }
            }
        }

        public List<GameObject> checkCollionsForEnemy()
        {
           
            foreach (GameObject GO in gameObjectList)
            {
                if (GO.getObjectType() == ObjectType.enemy)
                {

                    foreach (GameObject GO1 in gameObjectList)
                    {
                       
                        if (GO1.getObjectType() == ObjectType.bullet)
                        {
                            if (CollisionDetection.IsCollided(GO, GO1))
                            {
                                CollisionDetection cd = new CollisionDetection(GO, GO1);
                                collisions.Add(cd);
                                GO.health -= 5;
                                GO1.health -= 5;
                                container.Controls.Remove(GO1.getPictureBox());
                                gameObjectList.Remove(GO1);
                                return gameObjectList;

                            }
                        }
                    }
                }
                
            }
               return gameObjectList;
        }

        public List<CollisionDetection> getlist()
        {
            return this.collisions;
        }

        public void FirePlayer(Image img,Point boundary)
        {
            int left = 0, top = 0;
            foreach (GameObject gameobject in gameObjectList)
            {
                if (gameobject.getObjectType() == ObjectType.player)
                {
                    left = gameobject.getPictureBox().Left + gameobject.getPictureBox().Width+ 100;
                    top = (gameobject.getPictureBox().Top) + (gameobject.getPictureBox().Height / 2);
                    break;
                }
            }
            GameObject bullet = GameObject.CreateGameObject(img, left, top, new Bullets(30, boundary, Directions.right), ObjectType.bullet, 0);
            bullet.SetPictureBoxSize(75,25);
            AddGameObjects(bullet);
        }


        public void FireEnemy(Image img, Point boundary)
        {
            foreach(GameObject gameobject in gameObjectList)
            {
                if(gameobject.getObjectType()== ObjectType.enemy)
                {
                    if( playerlocation.Y - gameobject.GetGameObjectLocation().Y<=10 && playerlocation.Y - gameobject.GetGameObjectLocation().Y >=-10 )
                    {
                        AddGameObjects(gameobject.Fire(img, boundary));
                        break;
                    }
                }
            }
        }

        public int PlayerHealth()
        {
            foreach(GameObject gameobject in gameObjectList)
            {
                if (ObjectType.player == gameobject.getObjectType())
                {
                    return gameobject.getHealth();
                }
            }
            return 0;
        }

        public int EnemysHealth()
        {
            int enemyHealth = 0;
            foreach(GameObject gameobject in gameObjectList)
            {
                if(ObjectType.enemy == gameobject.getObjectType())
                {
                    enemyHealth += gameobject.getHealth();
                }
            }
            return enemyHealth;
        }

        public void removeObject()
        {
            foreach( GameObject gameobject in gameObjectList)
            {
                if (gameobject.health <= 0 && gameobject.getObjectType()!=ObjectType.bullet)
                {
                    container.Controls.Remove(gameobject.getPictureBox());
                    gameObjectList.Remove(gameobject);
                    break;
                }
            }
        }

        public void RemoveObject(GameObject gameObject)
        {
            foreach (GameObject GO in gameObjectList)
            {
                if (gameObject == GO)
                {
                    container.Controls.Remove(GO.getPictureBox());
                    gameObjectList.Remove(GO);
                    break;

                }
            }
        }
        public void removebullet()
        {
            foreach (GameObject gameobject in gameObjectList)
            {
               if(gameobject.getObjectType() == ObjectType.bullet)
                {
                    if(gameobject.getPictureBox().Location.X <= 0 || gameobject.getPictureBox().Location.X >= 1250)
                    {
                        gameobject.health = 0;
                        gameObjectList.Remove(gameobject) ;
                        break;
                    }
                    
                }
                   
             
            }
        }

        public Result CheckWinning()
        {
            int playercount=0;
            int enemycount = 0;
            
            foreach(GameObject gameobject in gameObjectList)
            {
                if(gameobject.getObjectType()==ObjectType.player)
                {
                    playercount++;
                }
                if (gameobject.getObjectType() == ObjectType.enemy)
                {
                    enemycount++;
                }
            }
            if (playercount == 0) return Result.Lose;
            if(enemycount == 0) return Result.Win;
            else return Result.Pending;
        }
    }
}
