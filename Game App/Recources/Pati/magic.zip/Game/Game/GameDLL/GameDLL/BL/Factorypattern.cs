﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace GameDLL.BL
{
    public static class Factorypattern
    {
        public static int Enemies;
        public static int Players;

        
    }
}
