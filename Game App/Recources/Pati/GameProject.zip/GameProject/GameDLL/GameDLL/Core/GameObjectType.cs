﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameDLL.Core
{
    public enum GameObjectType
    {
        Player,        
        Enemy1,
        Enemy2,
        Enemy3,
        Bullet1
    }
}
